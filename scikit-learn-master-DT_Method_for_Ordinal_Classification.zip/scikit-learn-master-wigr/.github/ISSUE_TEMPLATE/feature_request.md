---
name: Feature request
about: Suggest a new algorithm, enhancement to an existing algorithm, etc.
title: ''
labels: New Feature
assignees: ''

---

<!--
If you want to propose a new algorithm, please refer first to the scikit-learn
inclusion criterion:
https://scikit-learn.org/stable/faq.html#what-are-the-inclusion-criteria-for-new-algorithms
-->

#### Describe the workflow you want to enable

#### Describe your proposed solution

#### Describe alternatives you've considered, if relevant

#### Additional context
