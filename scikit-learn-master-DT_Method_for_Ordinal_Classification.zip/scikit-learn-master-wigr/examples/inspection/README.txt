.. _inspection_examples:

Inspection
----------

Examples related to the :mod:`sklearn.inspection` module.

